--
-- MySQL 5.5.5
-- Mon, 07 Jun 2021 18:06:40 +0000
--

CREATE TABLE `cashier` (
   `cashier_id` int(10) not null auto_increment,
   `cashier_name` varchar(100) not null,
   `position` varchar(100) not null,
   `username` varchar(100) not null,
   `password` varchar(100) not null,
   PRIMARY KEY (`cashier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;

INSERT INTO `cashier` (`cashier_id`, `cashier_name`, `position`, `username`, `password`) VALUES 
('1', 'Cashier', 'cashier', 'cashier', '12345');

CREATE TABLE `collection` (
   `transaction_id` int(11) not null auto_increment,
   `date` varchar(100) not null,
   `name` varchar(100) not null,
   `invoice` varchar(100) not null,
   `amount` varchar(100) not null,
   `remarks` varchar(100) not null,
   `balance` int(11) not null,
   PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

-- [Table `collection` is empty]

CREATE TABLE `customer` (
   `customer_id` int(11) not null auto_increment,
   `customer_name` varchar(100) not null,
   `address` varchar(100) not null,
   `contact` varchar(100) not null,
   `membership_number` varchar(100) not null,
   `first_name` varchar(50) not null,
   `middle_name` varchar(50) not null,
   `last_name` varchar(50) not null,
   PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=9;

INSERT INTO `customer` (`customer_id`, `customer_name`, `address`, `contact`, `membership_number`, `first_name`, `middle_name`, `last_name`) VALUES 
('3', 'Mukesh Kashyap Singh', 'Bharuch, Gujarat', '9242455677', 'Aj12Zyt', 'Mukesh', 'Kashyap', 'Singh'),
('4', 'Samir Saiyed -', 'Kosamba, Gujarat', '987462134', 'Ajztys', 'Samir', 'Saiyed', '-'),
('5', 'Surendra Rawat -', 'Clock tower,Bermuda', '8962412435', 'Ajzxty', 'Surendra', 'Rawat', '-'),
('6', 'Umang Shah -', 'Ankleshwar, Gujarat', '987345244', 'Ajztyf', 'Umang', 'Shah', '-'),
('7', 'Vikram The Legend', 'Peak, Bermuda', '987335245', 'Ajzxtr', 'Vikram', 'The', 'Legend'),
('8', 'K2s - -', 'Factory, Bermuda', '896412435', 'Ajztyd', 'K2s', '-', '-');

CREATE TABLE `lose` (
   `p_id` int(10) not null auto_increment,
   `product_code` varchar(30) not null,
   `product_name` varchar(30) not null,
   `description_name` varchar(30) not null,
   `amount_lose` varchar(30) not null,
   `qty` varchar(30) not null,
   `cost` varchar(30) not null,
   `date` varchar(30) not null,
   `category` varchar(20) not null,
   `exdate` varchar(30) not null,
   PRIMARY KEY (`p_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=4;

INSERT INTO `lose` (`p_id`, `product_code`, `product_name`, `description_name`, `amount_lose`, `qty`, `cost`, `date`, `category`, `exdate`) VALUES 
('1', 'P-08', 'Century Tuna', 'ADOBO', '3000', '100', '30', '02-23-2017', 'Canned Goods', '2017-05-27'),
('2', 'P-08', 'Century Tuna', 'ADOBO', '3000', '100', '30', '06-03-2021', 'Canned Goods', ''),
('3', 'P-08', 'Century Tuna', 'ADOBO', '3000', '100', '30', '06-03-2021', 'Canned Goods', '');

CREATE TABLE `products` (
   `product_id` int(11) not null auto_increment,
   `product_code` varchar(50) not null,
   `product_name` varchar(100) not null,
   `description_name` varchar(50) not null,
   `cost` varchar(100) not null,
   `supplier` varchar(100) not null,
   `qty_left` int(10) not null,
   `category` varchar(100) not null,
   PRIMARY KEY (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5;

INSERT INTO `products` (`product_id`, `product_code`, `product_name`, `description_name`, `cost`, `supplier`, `qty_left`, `category`) VALUES 
('1', 'P-08', 'Century Tuna', 'ADOBO', '30', 'Consuelo', '100', 'Canned Goods'),
('2', 'P-20032023', 'Lucky Me', 'Pancit Canton Extra Hot', '10', 'Consuelo', '100', 'Noodles'),
('3', 'P-20032043', 'Lucky Me', 'Pancit Canton Chilimansi', '10', 'Consuelo', '100', 'Noodles'),
('4', 'P-3932232', 'M.Y. San', 'Skyflakes Crackers', '45.50', 'Consuelo', '100', 'Crackers');

CREATE TABLE `purchases` (
   `transaction_id` int(11) not null auto_increment,
   `invoice_number` varchar(100) not null,
   `date_order` varchar(100) not null,
   `suplier` varchar(100) not null,
   `date_deliver` varchar(100) not null,
   `p_name` varchar(30) not null,
   `qty` varchar(30) not null,
   `cost` varchar(30) not null,
   `status` varchar(25) not null,
   `remark` varchar(100) not null,
   PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;

-- [Table `purchases` is empty]

CREATE TABLE `purchases_item` (
   `id` int(11) not null auto_increment,
   `name` varchar(100) not null,
   `qty` int(11) not null,
   `cost` varchar(100) not null,
   `invoice` varchar(100) not null,
   `status` varchar(25) not null,
   `date` varchar(25) not null,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;

-- [Table `purchases_item` is empty]

CREATE TABLE `sales` (
   `transaction_id` int(11) not null auto_increment,
   `invoice_number` varchar(100) not null,
   `cashier` varchar(100) not null,
   `date` varchar(100) not null,
   `type` varchar(100) not null,
   `amount` varchar(100) not null,
   `due_date` varchar(100) not null,
   `name` varchar(100) not null,
   `balance` varchar(100) not null,
   `total_amount` varchar(30) not null,
   `cash` varchar(100) not null,
   `month` varchar(20) not null,
   `year` varchar(20) not null,
   `p_amount` varchar(30) not null,
   `vat` varchar(30) not null,
   PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;

-- [Table `sales` is empty]

CREATE TABLE `sales_order` (
   `transaction_id` int(11) not null auto_increment,
   `invoice` varchar(100) not null,
   `product` varchar(100) not null,
   `qty` varchar(100) not null,
   `amount` varchar(100) not null,
   `name` varchar(100) not null,
   `price` varchar(100) not null,
   `discount` varchar(100) not null,
   `category` varchar(100) not null,
   `date` varchar(25) not null,
   `omonth` varchar(25) not null,
   `oyear` varchar(25) not null,
   `qtyleft` varchar(25) not null,
   `dname` varchar(50) not null,
   `vat` varchar(20) not null,
   `total_amount` varchar(30) not null,
   PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=3;

-- [Table `sales_order` is empty]

CREATE TABLE `supliers` (
   `suplier_id` int(11) not null auto_increment,
   `suplier_name` varchar(100) not null,
   `suplier_address` varchar(100) not null,
   `suplier_contact` varchar(100) not null,
   `contact_person` varchar(100) not null,
   PRIMARY KEY (`suplier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=4;

INSERT INTO `supliers` (`suplier_id`, `suplier_name`, `suplier_address`, `suplier_contact`, `contact_person`) VALUES 
('1', 'Vikram', 'Kim, Gujarat', '987654321', 'Furious'),
('2', 'Shon', 'Kim, Gujarat', '912345678', 'Shon'),
('3', 'Hardik', 'Bharuch, Gujarat', '993760732', 'Yds');

CREATE TABLE `user` (
   `id` int(11) not null auto_increment,
   `username` varchar(100) not null,
   `password` varchar(100) not null,
   `name` varchar(100) not null,
   `position` varchar(100) not null,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;

INSERT INTO `user` (`id`, `username`, `password`, `name`, `position`) VALUES 
('1', 'admin', 'admin123', 'Admin', 'Admin');